# IoT Telemetry Data Engineering Platform

## Overview
This project implements a streaming data ingestion platform for high-volume IoT telemetry data with schema evolution, data quality monitoring, and dual storage architecture (time-series + data lake).

## Architecture

### High-Level Design
```
IoT Devices → Kafka → Stream Processor → [TimescaleDB + Data Lake (Parquet)]
                                      ↓
                              Data Quality Monitor
                                      ↓
                              BI/ML Analytics Layer
```

### Key Components
1. **Kafka Ingestion**: Simulated Kafka consumer for IoT events
2. **Stream Processor**: Handles schema evolution and data transformation
3. **Dual Storage**: TimescaleDB for operational queries + Parquet files for analytics
4. **Data Quality**: Validation, monitoring, and alerting
5. **Migration Tools**: Historical data transformation and loading

## Step-by-Step Setup Guide for Your Personal Laptop

### Prerequisites Installation

#### 1. Install Python 3.8+
**Windows:**
- Download from https://www.python.org/downloads/
- During installation, check "Add Python to PATH"
- Verify: Open Command Prompt and run `python --version`

**macOS:**
```bash
# Using Homebrew (install Homebrew first from https://brew.sh/)
brew install python
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install python3 python3-pip
```

#### 2. Install Docker Desktop
- Download from https://www.docker.com/products/docker-desktop/
- Install and start Docker Desktop
- Verify: Run `docker --version` and `docker-compose --version`

#### 3. Install Git (if not already installed)
- Download from https://git-scm.com/downloads
- Verify: Run `git --version`

### Project Setup

#### Step 1: Clone the Repository
```bash
# Clone the project
git clone https://github.com/ndoudaniel1162/iot-telemetry-platform-daniel-ndou.git
cd iot-telemetry-platform-daniel-ndou
```

#### Step 2: Create Python Virtual Environment
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Verify activation (you should see (venv) in your prompt)
```

#### Step 3: Install Python Dependencies
```bash
# Install all required packages
pip install -r requirements.txt

# Verify installation
pip list
```

#### Step 4: Start Infrastructure Services
```bash
# Start PostgreSQL (TimescaleDB) and Kafka using Docker
docker-compose up -d

# Verify services are running
docker-compose ps

# You should see postgres and kafka containers running
```

#### Step 5: Initialize Database
```bash
# Wait 30 seconds for PostgreSQL to fully start, then run:
python src/setup_db.py
```

#### Step 6: Run the Complete Pipeline
```bash
# Run the main pipeline
python src/main.py
```

### What You Should See

1. **Sample data generation**: Creates 5,000 sample IoT events
2. **Stream processing**: Processes events in batches
3. **Data storage**: Saves to both TimescaleDB and Parquet files
4. **Quality monitoring**: Shows data quality report

### Additional Commands

#### Run Data Quality Monitor
```bash
python src/quality/monitor.py
```

#### Run Data Migration
```bash
python src/migration/migrate.py
```

#### Run Tests
```bash
# Install pytest if not already installed
pip install pytest

# Run all tests
python -m pytest tests/ -v
```

#### View Database Data
```bash
# Connect to PostgreSQL (password: password)
docker exec -it <postgres_container_name> psql -U postgres -d iot_telemetry

# Inside PostgreSQL, run:
SELECT COUNT(*) FROM telemetry;
SELECT device_id, COUNT(*) FROM telemetry GROUP BY device_id;
```

### Troubleshooting

#### If Docker services fail to start:
```bash
# Stop all services
docker-compose down

# Remove volumes and restart
docker-compose down -v
docker-compose up -d
```

#### If Python packages fail to install:
```bash
# Upgrade pip first
pip install --upgrade pip

# Try installing again
pip install -r requirements.txt
```

#### If database connection fails:
```bash
# Check if PostgreSQL container is running
docker-compose ps

# Check logs
docker-compose logs postgres
```

### Stopping the Services
```bash
# Stop all Docker services
docker-compose down

# Deactivate Python virtual environment
deactivate
```

## Project Structure
```
├── src/
│   ├── ingestion/          # Kafka simulation and ingestion
│   ├── processing/         # Stream processing and transformation
│   ├── storage/           # Database and file storage handlers
│   ├── quality/           # Data quality monitoring
│   └── migration/         # Historical data migration tools
├── config/                # Configuration files
├── data/                 # Sample data and outputs
├── tests/                # Unit tests
└── docker-compose.yml    # Infrastructure setup
```

## Running the Solution

### Option 1: Standalone Mode (Recommended for Demo)
```bash
# No Docker required - uses SQLite
python src/main_standalone.py
```

### Option 2: Full Docker Mode
1. **Start Infrastructure**: `docker-compose up -d`
2. **Initialize Database**: `python src/setup_db.py`
3. **Run Pipeline**: `python src/main.py`
4. **Check Data Quality**: `python src/quality/monitor.py`
5. **Run Migration**: `python src/migration/migrate.py`

## Key Design Decisions

### Topic Design & Partitioning
- Partition by device_id for ordered processing per device
- Separate topics for different device types if needed
- Retention policy based on operational vs analytical needs

### Schema Evolution
- Avro schema registry simulation with backward compatibility
- Graceful handling of missing/new fields
- Version tracking in metadata

### Error Handling
- Dead letter queue for failed records
- Retry mechanism with exponential backoff
- Comprehensive logging and alerting

### Performance Considerations
- Batch processing for efficiency
- Parallel processing where possible
- Optimized storage formats (Parquet with compression)

## Trade-offs Made

1. **Simplicity vs Production Scale**: Used file-based simulation instead of full Kafka setup
2. **Storage**: PostgreSQL with TimescaleDB extension vs dedicated time-series DB
3. **Schema Registry**: Simulated vs full Confluent Schema Registry
4. **Monitoring**: Basic logging vs comprehensive observability stack

## Future Improvements

1. **Production Infrastructure**: Full Kafka cluster, Schema Registry, monitoring stack
2. **Advanced Analytics**: Real-time aggregations, anomaly detection
3. **Scalability**: Kubernetes deployment, auto-scaling
4. **Security**: Encryption, authentication, authorization
5. **Testing**: Integration tests, performance testing
6. **Observability**: Metrics, tracing, alerting

## Testing
```bash
# Run unit tests
python -m pytest tests/

# Run integration tests
python -m pytest tests/integration/
```