# Interview Presentation - Essential Files

## Files Included in Interview Package

### Documentation (5 files)
- README.md - Project overview and quick start
- INTERVIEW_PRESENTATION_GUIDE.md - Your presentation guide
- architecture.md - Architecture design document
- SETUP_GUIDE.md - Setup instructions
- requirements_simple.txt - Python dependencies

### Source Code - Core (12 files)
- src/__init__.py
- src/main_simple.py - Main entry point (DEMO THIS)
- src/models.py - Data models and schema evolution
- src/config_standalone.py - Configuration

#### Ingestion Module
- src/ingestion/__init__.py
- src/ingestion/kafka_simulator.py - Data generation

#### Processing Module
- src/processing/__init__.py
- src/processing/stream_processor.py - Stream processing logic

#### Storage Module
- src/storage/__init__.py
- src/storage/database_simple.py - SQLite database handler
- src/storage/data_lake_simple.py - JSON data lake handler

#### Quality Module
- src/quality/__init__.py
- src/quality/validator.py - Data validation
- src/quality/monitor.py - Quality monitoring

### Tests (3 files)
- tests/__init__.py
- tests/test_models.py
- tests/test_validator.py

### Configuration (1 file)
- .gitignore

### Data Directory Structure
- data/ (empty folder - will be created on run)

## Total: 21 essential files

## Files EXCLUDED (not needed for interview)
- .git/ - Git history
- venv/ - Virtual environment (recreate locally)
- __pycache__/ - Python cache files
- *.db - Database files (generated on run)
- *.zip - Old zip files
- Docker files (docker-compose.yml, init.sql)
- Full mode files (main.py, database.py, data_lake.py, etc.)
- Submission guides and packaging instructions
- .env.example
- Old requirements files

## Why This Selection?

### Included:
✅ All code needed to run the demo
✅ Documentation for presentation
✅ Tests to show quality
✅ Simple mode only (no Docker complexity)

### Excluded:
❌ Docker setup (adds complexity, not needed for demo)
❌ Full mode files (focus on simple, working demo)
❌ Generated files (database, cache)
❌ Submission/packaging docs (not relevant for interview)
❌ Git history (not needed for presentation)

## Setup After Unzipping

```bash
# Extract the zip
# Navigate to folder
cd iot-telemetry-interview

# Create virtual environment
python -m venv venv

# Activate virtual environment
venv\Scripts\activate  # Windows
source venv/bin/activate  # Mac/Linux

# Install dependencies
pip install -r requirements_simple.txt

# Run the demo
python src/main_simple.py
```

## File Size
- Original project: ~50+ files, multiple MB
- Interview package: 21 files, < 100 KB (without venv)
- Clean, focused, professional
